#include "stm32f10x.h"                  // Device header
void BUZZER_Init(void) {
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    
    
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;  // 推挽输出
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_All;       
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz; // 高速模式
    GPIO_Init(GPIOB, &GPIO_InitStruct);
    
    
    GPIO_SetBits(GPIOB, GPIO_Pin_All);
}


void BUZZER_ON(uint16_t GPIO_Pin_x) {
    GPIO_ResetBits(GPIOB, GPIO_Pin_x);  // 低电平
}


void BUZZER_OFF(uint16_t GPIO_Pin_x) {
    GPIO_SetBits(GPIOB, GPIO_Pin_x);    // 高电平
}


void BUZZER_Toggle(uint16_t GPIO_Pin_x) 
	{
    GPIOB->ODR ^= GPIO_Pin_x;  // 异或操作直接翻转电平（高效）
}