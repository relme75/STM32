#ifndef _SERVO_H
#define _SERVO_H
void Servo_SetAngle(float Angle);

void Servo_Init(void);
#endif
