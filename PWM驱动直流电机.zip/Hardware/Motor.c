#include "stm32f10x.h"                  // Device header
#include "PWM.h"
#include <stdlib.h>


void  Motor_Init(void)
{
	PWM_Init();
	 // 1. 使能GPIOA时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    
    // 2. 配置GPIOA所有引脚为推挽输出
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;  // 推挽输出
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_4|GPIO_Pin_5;       
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz; // 高速模式
    GPIO_Init(GPIOA, &GPIO_InitStruct);
 
}

void Motor_SetSpeed(int8_t Speed)
{
    uint16_t actual_compare = abs (Speed) * (7200-1) / 100;
    
    if(Speed >= 0) {
        GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_RESET);
    } else {
        GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_SET);
    }
    
    TIM_SetCompare3(TIM2, actual_compare);
}