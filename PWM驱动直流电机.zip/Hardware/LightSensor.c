#include "stm32f10x.h"                  // Device header
 void Light_sensor_Init(void)
	{	
	    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE); //外设时钟
		GPIO_InitTypeDef GPIO_InitStructure;  //定义结构体名字
		GPIO_InitStructure.GPIO_Mode= GPIO_Mode_IPU;   //上拉输入
		GPIO_InitStructure.GPIO_Pin= GPIO_Pin_13 ;
		GPIO_InitStructure.GPIO_Speed= GPIO_Speed_50MHz;   //频率
		GPIO_Init(GPIOB,&GPIO_InitStructure);                  //取地址
	}

uint8_t Light_sensor_Get(void)
{
	return(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13));	
	
}