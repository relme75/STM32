#include "stm32f10x.h"                  
#include "OLED.h" 
#include "Delay.h"
#include "Timer.h"
#include "Motor.h"
#include "key.h"
int keynum;
int Speed=0;
int main()
{
	OLED_Init();
	Motor_Init();
	key_Init();
	OLED_ShowString(1,1,"Speed:");
	OLED_ShowString(2,6,"Love you");
	while(1)
    {
	keynum=key_GetNum();
		if(keynum==1)
		{
			Speed+=10;
			if(Speed>100)
			{
				Speed=-100;
			}
		}
		Motor_SetSpeed(Speed);
		OLED_ShowSignedNum(1,7,Speed,3);
    }
}
	
