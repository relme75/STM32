#include "led.h"

/**
  * @brief  初始化GPIOA所有引脚为推挽输出
  */
void LED_Init(void) {
    // 1. 使能GPIOA时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    
    // 2. 配置GPIOA所有引脚为推挽输出
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;  // 推挽输出
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_All;       // 所有引脚（A0-A15）
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz; // 高速模式
    GPIO_Init(GPIOA, &GPIO_InitStruct);
    
    // 3. 默认关闭所有LED（高电平熄灭）
    GPIO_SetBits(GPIOA, GPIO_Pin_All);
}

/**
  * @brief  点亮指定引脚的LED（低电平有效）
  * @param  GPIO_Pin_x: 引脚号（如GPIO_Pin_0, GPIO_Pin_1等）
  */
void LED_ON(uint16_t GPIO_Pin_x) {
    GPIO_ResetBits(GPIOA, GPIO_Pin_x);  // 低电平点亮
}

/**
  * @brief  熄灭指定引脚的LED（高电平有效）
  */
void LED_OFF(uint16_t GPIO_Pin_x) {
    GPIO_SetBits(GPIOA, GPIO_Pin_x);    // 高电平熄灭
}

/**
  * @brief  翻转指定引脚的电平状态
  */
void LED_Toggle(uint16_t GPIO_Pin_x) {
    GPIOA->ODR ^= GPIO_Pin_x;  // 异或操作直接翻转电平（高效）
}