#include "stm32f10x.h"
#include "led.h"
#include "delay.h"  // 假设有延时函数（需自行实现）
#include "key.h" 
 uint8_t keynum;
int main(void) 
	{
    LED_Init();
    key_Init();
   
    while(1) 
		{
		keynum = key_GetNum();
        if(keynum==1)
		{
			LED_Toggle(GPIO_Pin_10);
			
		}
		
		if(keynum==11)
		{
			
			LED_Toggle(GPIO_Pin_10);
		}	
    }					
}