#ifndef _key_h
#define _key_h

void key_Init(void);
uint8_t key_GetNum(void);

#endif