#ifndef _COUNT_SENSOR_H
#define _COUNT_SENSOR_H

void CountSensor_Init(void);
uint16_t Count_sensor_get(void);
#endif
