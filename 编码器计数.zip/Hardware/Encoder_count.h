#ifndef _ENCODER_count_H
#define _ENCODER_count_H

int16_t Encoder_count_get(void);
void Encoder_count_Init(void);


#endif
