#include "stm32f10x.h"                  // Device header
#include "OLED.h" 
#include "Delay.h"
#include "Timer.h"
#include "Encoder_count.h"




int main()
{
//	 Timer_Init();
	OLED_Init();
	Encoder_count_Init();
	OLED_ShowString(1,1,"CNT:");
	while(1)
	{
		
		OLED_ShowSignedNum(1,5,Encoder_count_get(),5);
		Delay_ms(1000);
		
	}
	
}
//void TIM2_IRQHandler(void)   //中断函数
//{
//	if(TIM_GetITStatus(TIM2,TIM_IT_Update)==SET)
//{
//	num++;
//	TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
//}	
//}