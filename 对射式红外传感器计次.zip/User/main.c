#include "stm32f10x.h"                  // Device header
#include "OLED.h" 
#include "Delay.h"
#include "key.h"
#include "Countsensor.h"


int main()
{
	
	OLED_Init();
	CountSensor_Init();
	OLED_ShowString(1,1,"Count:");
	while(1)
	{
		OLED_ShowNum(1,7,Count_sensor_get(),5);
	}
	
	 
	
}