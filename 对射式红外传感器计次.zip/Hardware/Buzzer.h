#ifndef __BUZZER_H
#define __BUZZER_H
void BUZZER_Init(void);
void BUZZER_ON(uint16_t GPIO_Pin_x);
void BUZZER_OFF(uint16_t GPIO_Pin_x);
void BUZZER_Toggle(uint16_t GPIO_Pin_x);
#endif
