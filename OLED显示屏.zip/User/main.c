#include "stm32f10x.h"                  // Device header
#include "OLED.h" 
#include "Delay.h"
#include "key.h"
int keynum;

int main()
{
	key_Init();
	OLED_Init();
	int count=0;
	OLED_ShowNum(1,1,count,3);
	while(1)
	{
		keynum=key_GetNum();
		if(keynum==12)
	{
		count++;
		OLED_ShowNum(1,1,count,3);
		Delay_ms(200);
		while(key_GetNum()==12);
		Delay_ms(200);
		if(count==10)
		{
			Delay_ms(200);
	count=0;
	OLED_ShowNum(1,1,count,3);
		}
	}
	}
	
}