#include "stm32f10x.h"                  // Device header
#include "delay.h"
#include "Buzzer.h"
#include "LightSensor.h"
int main(void)
{
	BUZZER_Init();
	Light_sensor_Init();
	while(1)
	{BUZZER_ON(GPIO_Pin_10);
		if(Light_sensor_Get()==1)
		{
			BUZZER_ON(GPIO_Pin_10);
			
		}
		else
     { 
	        BUZZER_OFF(GPIO_Pin_10);
     }
	}
}
	