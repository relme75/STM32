#include "stm32f10x.h"   // 包含正确的头文件
#include "delay.h"
#define  COUNT 99

 int main()
{
    // 1. 初始化系统时钟（关键！）
    SystemInit();

    // 2. 启用GPIOA的时钟（APB2总线）
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    // 3. 配置PA0为推挽输出
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_Out_PP;  // 推挽输出
    GPIO_InitStruct.GPIO_Pin   = GPIO_Pin_0;        // PA0
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;  // 速度50MHz
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    int i=0;
    while(1)
    { 
        i++;
		GPIO_SetBits(GPIOA, GPIO_Pin_0);
        Delay_ms(500);
        GPIO_ResetBits(GPIOA, GPIO_Pin_0);
        Delay_ms(500);
		if(i==COUNT)
		{
		break;			
		}
    }
	while(1)
	{
	}
}