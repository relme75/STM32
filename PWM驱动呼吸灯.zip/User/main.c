#include "stm32f10x.h"                  // Device header
#include "OLED.h" 
#include "Delay.h"
#include "Timer.h"
#include "PWM.h"

uint8_t i;

int main()
{
	
	OLED_Init();
	PWM_Init();
	
	while(1)
{
	for(i=0;i<100;i++)
	{
		PWM_setcomper1(i);
		Delay_ms(10);
	}
	for(i=0;i<100;i++)
	{
		PWM_setcomper1(100-i);
		Delay_ms(10);
	}
    
    }
}
	

