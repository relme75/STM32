#ifndef _PWM_H
#define _PWM_H

void PWM_Init(void);
void PWM_setcomper2(uint16_t Compare);






#endif
