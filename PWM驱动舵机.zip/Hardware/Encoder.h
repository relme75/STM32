#ifndef _ENCODER_H
#define _ENCODER_H
int16_t Encoder_get(void);
void Encoder_Init(void);



#endif
