#include "stm32f10x.h"

void PWM_Init(void)
{
    // 1. 开启时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    // 2. 配置GPIOA Pin0为复用推挽输出（关键修正点：GPIOA而非GPIOB）
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;       // 复用推挽输出
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);                // 修正为GPIOA

    // 3. 配置定时器时基单元（关键修正点：使用内部时钟，移除外部时钟配置）
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
    TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInitStruct.TIM_Period = 20000 - 1;          // PWM周期
    TIM_TimeBaseInitStruct.TIM_Prescaler = 72 - 1;       // 预分频值
    TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStruct);

    // 4. 配置PWM输出通道
    TIM_OCInitTypeDef TIM_OCInitStruct;
    TIM_OCStructInit(&TIM_OCInitStruct);                  // 初始化结构体默认值
    TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;        // PWM模式1
    TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High; // 输出极性高
    TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable; // 使能输出
    TIM_OCInitStruct.TIM_Pulse = 0;                      // 初始占空比50%
    TIM_OC2Init(TIM2, &TIM_OCInitStruct);

    // 5. 使能定时器
    TIM_Cmd(TIM2, ENABLE);
}


void PWM_setcomper2(uint16_t Compare)
{
	TIM_SetCompare2(TIM2, Compare);
}