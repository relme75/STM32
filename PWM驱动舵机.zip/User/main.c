#include "stm32f10x.h"                  
#include "OLED.h" 
#include "Delay.h"
#include "Timer.h"
#include "Servo.h"
#include "key.h"
int keynum;
float Angle;
int main()
{
	
	OLED_Init();
	Servo_Init();
	key_Init();
	OLED_ShowString(1,1,"Angle:");
	
	while(1)
    {
	OLED_ShowNum(1,7,Angle,3);
	keynum=key_GetNum();
	 if(keynum==1)
     {
	  Angle+=30;
		 if(Angle>180)
		 {
			  Angle=0;
		 }
	    Servo_SetAngle(Angle);
	 }

    }
}
	

