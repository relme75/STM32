#ifndef __LIGHT_SENSOR_H
#define __LIGHT_SENSOR_H
 uint8_t Light_sensor_Get(void);
 void Light_sensor_Init(void);


#endif
