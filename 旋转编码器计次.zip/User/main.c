#include "stm32f10x.h"                  // Device header
#include "OLED.h" 
#include "Delay.h"
#include "key.h"
#include "Encoder.h"

int16_t num;
int main()
{
	
	OLED_Init();
	Encoder_Init();
	OLED_ShowString(1,1,"num:");
	while(1)
	{
		num+=Encoder_get();
		OLED_ShowSignedNum(1,5,num,5);
		
	}
	
	 
	
}