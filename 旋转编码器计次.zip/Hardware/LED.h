#ifndef __LED_H
#define __LED_H

#include "stm32f10x.h"

// 初始化函数
void LED_Init(void);  // 初始化GPIOA所有引脚为推挽输出

// 通用控制函数（支持A0-A15任意引脚）
void LED_ON(uint16_t GPIO_Pin_x);     // 点亮LED（低电平）
void LED_OFF(uint16_t GPIO_Pin_x);    // 熄灭LED（高电平）
void LED_Toggle(uint16_t GPIO_Pin_x); // 翻转LED状态

#endif
